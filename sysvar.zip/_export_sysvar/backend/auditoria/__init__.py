default_app_config = "auditoria.apps.AuditoriaConfig"
