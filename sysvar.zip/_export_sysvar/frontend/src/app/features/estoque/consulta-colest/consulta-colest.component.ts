// src/app/features/estoque/consulta-colest/consulta-colest.component.ts
import { Component, inject, signal } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EstoquesService } from '../../../core/services/estoques.service';
import { TabelaprecoService } from '../../../core/services/tabelapreco.service';

type ColEst = { colecao: string; estacao: string; rotulo: string };
type LinhaLoja = {
  loja_id: number; loja_nome: string;
  colest: Record<string, { itens: number; valor: number }>;
  total_itens: number; total_valor: number;
};

@Component({
  selector: 'app-consulta-colest',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './consulta-colest.component.html',
  styleUrls: ['./consulta-colest.component.css'],
  providers: [CurrencyPipe]
})
export class ConsultaColEstComponent {
  private api = inject(EstoquesService);
  private moeda = inject(CurrencyPipe);
  private tabelasApi = inject(TabelaprecoService);

  // filtros
  colecoes = signal<string[]>([]);
  estacoes = signal<string[]>([]);
  lojas = signal<number[]>([]);
  tabelaPrecoId = signal<number | null>(null);
  ativo = signal<'true'|'false'|'all'>('true');

  // estado
  loading = signal(false);
  error = signal<string | null>(null);

  // dados
  eixos_colest = signal<ColEst[]>([]);
  linhas = signal<LinhaLoja[]>([]);
  totais_colest = signal<Record<string, {itens:number; valor:number}>>({});
  total_geral_itens = signal(0);
  total_geral_valor = signal(0);

  // dropdown de tabelas de preço
  tabelasPreco: Array<{Idtabela:number; NomeTabela:string}> = [];

  ngOnInit() {
    this.tabelasApi.list({ ordering: 'NomeTabela' }).subscribe({
      next: (res:any) => { this.tabelasPreco = Array.isArray(res) ? res : (res?.results ?? []); }
    });
  }

  /** Helpers de parsing dos inputs CSV do template */
  onColecoesEnter(raw: string) {
    const arr = (raw || '')
      .split(',')
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => s.padStart(2, '0')); // garante 2 dígitos
    this.colecoes.set(arr);
  }
  onEstacoesEnter(raw: string) {
    const arr = (raw || '')
      .split(',')
      .map(s => s.trim())
      .filter(Boolean)
      .map(s => s.padStart(2, '0'));
    this.estacoes.set(arr);
  }
  onLojasEnter(raw: string) {
    const arr = (raw || '')
      .split(',')
      .map(s => parseInt(s.trim(), 10))
      .filter(n => !Number.isNaN(n) && n > 0);
    this.lojas.set(arr);
  }

  /** Formatação monetária */
  fmtValor(v: number): string {
    // BRL, com pt-BR. Se não quiser símbolo: use 'code' e troque para 'BRL'
    return this.moeda.transform(v || 0, 'BRL', 'symbol', '1.2-2', 'pt-BR') ?? 'R$ 0,00';
  }

  buscar(): void {
    this.error.set(null);
    if (!this.tabelaPrecoId()) {
      this.error.set('Selecione a Tabela de Preço.');
      return;
    }
    this.loading.set(true);

    this.api.matrizColEst({
      colecoes: this.colecoes(),
      estacoes: this.estacoes(),
      lojas: this.lojas(),
      tabela_preco_id: this.tabelaPrecoId()!,
      ativo: this.ativo()
    }).subscribe({
      next: (res:any) => {
        this.loading.set(false);
        this.eixos_colest.set(res?.eixos?.colest ?? []);
        // normaliza linhas para evitar undefined no template
        const linhas: LinhaLoja[] = (res?.matriz?.por_loja ?? []).map((l: any) => ({
          loja_id: l.loja_id,
          loja_nome: l.loja_nome,
          colest: l.colest ?? {},
          total_itens: l.total_itens ?? 0,
          total_valor: l.total_valor ?? 0,
        }));
        this.linhas.set(linhas);

        this.totais_colest.set(res?.matriz?.totais?.por_colest ?? {});
        const geral = res?.matriz?.totais?.geral ?? {itens:0, valor:0};
        this.total_geral_itens.set(geral.itens || 0);
        this.total_geral_valor.set(geral.valor || 0);
      },
      error: (err) => {
        this.loading.set(false);
        this.error.set(err?.error?.detail || 'Falha na consulta.');
      }
    });
  }
}
