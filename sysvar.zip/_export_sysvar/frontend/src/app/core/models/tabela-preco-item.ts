export interface TabelaPrecoItem {
  Idtabelaitem?: number;
  codigoproduto: string; // referencia
  codigodebarra: string; // EAN
  preco: number;
  idtabela: number;      // Idtabela
}
