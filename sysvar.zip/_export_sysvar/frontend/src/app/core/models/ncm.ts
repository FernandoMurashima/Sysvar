export interface Ncm {
  ncm: string;
  descricao: string;
  aliquota: string;
  campo1?: string | null;
}
