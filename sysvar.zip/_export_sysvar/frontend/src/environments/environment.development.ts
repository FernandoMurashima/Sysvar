export const environment = {
  production: false,
  apiBaseUrl: '/api',   // <- apenas /api
};
