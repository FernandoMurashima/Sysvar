export const environment = {
  production: true,
  apiBaseUrl: 'http://127.0.0.1:8000/api'
};
