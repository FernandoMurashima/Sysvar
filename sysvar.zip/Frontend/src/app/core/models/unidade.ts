export interface Unidade {
  Idunidade?: number;
  Descricao: string;
  Codigo?: string | null;
  data_cadastro?: string;  // readonly do backend
}
