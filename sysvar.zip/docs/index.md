# SysMura

Bem-vindo à documentação do **SysMura** 🛍️  

Este site é o **ponto central de referência** do projeto.  
Aqui registramos objetivos, visão, governança de acessos, arquitetura e processos.  

> Documentação viva: qualquer decisão ou mudança deve ser refletida aqui.
